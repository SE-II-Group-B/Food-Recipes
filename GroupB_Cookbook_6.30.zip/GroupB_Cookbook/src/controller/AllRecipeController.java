package controller;

import database.RecipeDAO;
import entity.Recipe;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.stage.Stage;
import view.CurrentRecipeView;
import view.MainView;

import java.io.File;

public class AllRecipeController {

    private final RecipeDAO dao = new RecipeDAO();

    public void openRecipeDetail(Recipe recipe, Node source) {
        Stage newStage = new Stage();
        CurrentRecipeView detailView = new CurrentRecipeView(recipe);
        newStage.setTitle("Recipe Detail");
        newStage.setScene(new Scene(detailView, 800, 600));
        newStage.show();
    }

    public void goBackToMain(Node source) {
        Stage current = (Stage) source.getScene().getWindow();
        current.close();

        Stage mainStage = new Stage();
        mainStage.setScene(new Scene(new MainView(), 800, 600));
        mainStage.setTitle("Main Menu");
        mainStage.show();
    }

    public void deleteRecipe(Recipe recipe) {
        dao.deleteRecipeById(recipe.getRecipeId());

        // 删除图片文件
        File image = new File("resources/img/" + recipe.getImgPath());
        if (image.exists()) {
            image.delete();
        }
    }
}
