package view;

import controller.HistoryController;
import entity.Recipe;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class HistoryView extends BorderPane {

    private final TableView<Recipe> historyTable = new TableView<>();
    private final Button backButton = new Button("Back");
    private final HistoryController controller = new HistoryController();

    public HistoryView() {
        TableColumn<Recipe, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("recipeId"));

        TableColumn<Recipe, String> nameCol = new TableColumn<>("Recipe Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("recipeName"));

        historyTable.getColumns().addAll(idCol, nameCol);
        historyTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        historyTable.setItems(loadMockData());

        historyTable.setRowFactory(tv -> {
            TableRow<Recipe> row = new TableRow<>();
            row.setOnMouseClicked(e -> {
                if (!row.isEmpty()) {
                    Recipe selected = row.getItem();
                    controller.openRecipeDetail(selected, row);
                }
            });
            return row;
        });

        backButton.setOnAction(e -> controller.goBackToMain(backButton));

        VBox content = new VBox(20, historyTable, backButton);
        content.setPadding(new Insets(20));

        ScrollPane scrollPane = new ScrollPane(content);
        scrollPane.setFitToWidth(true);

        this.setCenter(scrollPane);

        // 设置关闭按钮行为
        this.sceneProperty().addListener((obs, oldScene, newScene) -> {
            if (newScene != null) {
                Stage stage = (Stage) newScene.getWindow();
                stage.setOnCloseRequest((WindowEvent e) -> controller.goBackToMain(historyTable));
            }
        });
    }

    private ObservableList<Recipe> loadMockData() {
        return FXCollections.observableArrayList(
                new Recipe(101, "Viewed: Salad", ""),
                new Recipe(102, "Edited: Pasta", ""),
                new Recipe(103, "Created: Soup", "")
        );
    }
}
