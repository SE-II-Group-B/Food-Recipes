package view;

import controller.MainController;
import javafx.scene.control.Label;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class MainView extends BorderPane {

    private final MainController controller = new MainController();

    public MainView() {
        this.setPadding(new Insets(20));

        // 顶部按钮区域
        Button allRecipeButton = new Button("All Recipes");
        Button createRecipeButton = new Button("Create Recipe");
        Button historyButton = new Button("History");

        // 事件绑定：跳转到各自页面
        allRecipeButton.setOnAction(e -> controller.openAllRecipe(allRecipeButton));
        createRecipeButton.setOnAction(e -> controller.openCreateRecipe(createRecipeButton));
        historyButton.setOnAction(e -> controller.openHistory(historyButton));

        HBox topButtons = new HBox(20, allRecipeButton, createRecipeButton, historyButton);
        topButtons.setAlignment(Pos.CENTER);
        topButtons.setPadding(new Insets(20));
        
        Label titleLabel = new Label("Welcome to the Cookbook!");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #333;");
        titleLabel.setAlignment(Pos.CENTER);  
        VBox titleBox = new VBox(titleLabel);
        titleBox.setAlignment(Pos.CENTER);
        titleBox.setPadding(new Insets(0,0,40,0)); 
        
        // 搜索框和搜索按钮
        TextField searchField = new TextField();
        searchField.setPromptText("Search recipes...");
        searchField.setMaxWidth(300);
        Button searchButton = new Button("Search");
        // 搜索按钮事件绑定，传递文本框内容
        searchButton.setOnAction(e -> controller.openSearchView(searchButton, searchField.getText()));
        HBox searchBox = new HBox(10, searchField, searchButton);
        searchBox.setAlignment(Pos.CENTER);
        VBox centerBox = new VBox(titleBox, searchBox);
        centerBox.setAlignment(Pos.CENTER);

        this.setTop(topButtons);
        this.setCenter(centerBox);
    }
}
