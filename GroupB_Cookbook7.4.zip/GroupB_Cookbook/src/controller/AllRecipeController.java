package controller;

import database.RecipeDAO;
import entity.Recipe;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.stage.Stage;
import view.CurrentRecipeView;
import view.MainView;

import java.io.File;

public class AllRecipeController {

    private final RecipeDAO dao = new RecipeDAO();

    public void openRecipeDetail(Recipe recipe, Node source) {
        CurrentRecipeView recipeView = new CurrentRecipeView(recipe);
        Stage stage = new Stage();
        stage.setTitle("Recipe Detail");

        // ✅ 关闭当前 AllRecipe 窗口
        Stage current = (Stage) source.getScene().getWindow();
        current.close();

        stage.setScene(new Scene(recipeView, 800, 600));
        stage.show();
    }

    public void goBackToMain(Node source) {
        Stage current = (Stage) source.getScene().getWindow();
        current.close();

        Stage mainStage = new Stage();
        mainStage.setScene(new Scene(new MainView(), 800, 600));
        mainStage.setTitle("Main Menu");
        mainStage.show();
    }

    public void deleteRecipe(Recipe recipe) {
        dao.deleteRecipeById(recipe.getRecipeId());

        // 删除图片文件
        File image = new File("resources/img/" + recipe.getImgPath());
        if (image.exists()) {
            image.delete();
        }
    }
}
