package controller;

import database.RecipeDAO;
import entity.Recipe;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import view.CreateRecipeView;
import view.CurrentRecipeView;
import view.MainView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class CreateRecipeController {

    private final CreateRecipeView view;
    private final RecipeDAO recipeDAO = new RecipeDAO();
    private File selectedImageSource = null;

    public CreateRecipeController(CreateRecipeView view) {
        this.view = view;
    }

    public void handleImageSelection() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Recipe Image");
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")
        );
        File selected = fileChooser.showOpenDialog(null);
        if (selected != null) {
            selectedImageSource = selected;
            String recipeName = view.getRecipeNameField().getText().trim().replaceAll("\\s+", "_");
            String extension = selected.getName().substring(selected.getName().lastIndexOf("."));
            String suggestedName = recipeName + "_img" + extension;
            view.getImageNameField().setText(suggestedName);
        }
    }

    public void addInitialIngredients(int count) {
        for (int i = 0; i < count; i++) addIngredientRow();
    }

    public void addIngredientRow() {
        HBox row = new HBox(10);
        TextField name = new TextField();
        TextField quantity = new TextField();
        TextField unit = new TextField();
        Button remove = new Button("-");

        name.setPromptText("Name");
        quantity.setPromptText("Quantity");
        unit.setPromptText("Unit");

        quantity.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!newVal.matches("\\d*")) {
                quantity.setText(newVal.replaceAll("[^\\d]", ""));
            }
        });

        remove.setOnAction(e -> view.getIngredientBox().getChildren().remove(row));
        row.getChildren().addAll(name, quantity, unit, remove);
        view.getIngredientBox().getChildren().add(row);
    }

    public void addInitialSteps(int count) {
        for (int i = 0; i < count; i++) addStepRow();
    }

    public void addStepRow() {
        HBox row = new HBox(10);
        TextArea instruction = new TextArea();
        Button remove = new Button("-");

        instruction.setPromptText("Instruction");
        instruction.setPrefRowCount(3);
        instruction.setWrapText(true);
        instruction.setPrefWidth(500);

        remove.setOnAction(e -> view.getStepBox().getChildren().remove(row));
        row.getChildren().addAll(instruction, remove);
        view.getStepBox().getChildren().add(row);
    }

    public void saveRecipe(javafx.event.ActionEvent event) {
        try {
            String name = view.getRecipeNameField().getText().trim();
            String imagePath = view.getImageNameField().getText().trim();
            String description = view.getDescriptionArea().getText().trim();

            Recipe existing = recipeDAO.getRecipeByName(name);
            boolean isEdit = (existing != null);
            int recipeId = isEdit ? existing.getRecipeId() : recipeDAO.getNextAvailableRecipeId();

            if (isEdit) {
                recipeDAO.deleteRecipeById(recipeId);
            }

            if (selectedImageSource != null && !imagePath.isEmpty()) {
                File dest = new File("resources/img/" + imagePath);
                if (dest.exists()) {
                    Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
                    confirm.setTitle("Confirm Image Overwrite");
                    confirm.setHeaderText(null);
                    confirm.setContentText("You are about to overwrite a stored image.");
                    confirm.showAndWait().ifPresent(response -> {
                        if (response == ButtonType.OK) {
                            dest.delete();
                            try {
                                copyFile(selectedImageSource, dest);
                            } catch (IOException ex) {
                                showAlert("Failed to overwrite image.");
                            }
                        }
                    });
                } else {
                    copyFile(selectedImageSource, dest);
                }
            }

            recipeDAO.insertRecipe(recipeId, name, description, imagePath);

            for (javafx.scene.Node node : view.getIngredientBox().getChildren()) {
                if (node instanceof HBox row) {
                    TextField ingName = (TextField) row.getChildren().get(0);
                    TextField qty = (TextField) row.getChildren().get(1);
                    TextField unit = (TextField) row.getChildren().get(2);

                    String ing = ingName.getText().trim();
                    String unitStr = unit.getText().trim();
                    int quantity = qty.getText().trim().isEmpty() ? 0 :
                            Integer.parseInt(qty.getText().trim());

                    if (!ing.isEmpty() && !unitStr.isEmpty() && quantity > 0) {
                        recipeDAO.insertIngredient(recipeId, ing, unitStr, quantity);
                    }
                }
            }
            int step_id = 0 ;

            for (javafx.scene.Node node : view.getStepBox().getChildren()) {
                if (node instanceof HBox row) {
                    TextArea instruction = (TextArea) row.getChildren().get(0);
                    String text = instruction.getText().trim();
                    step_id++; 
                    if (!text.isEmpty()) {
                        recipeDAO.insertStep(recipeId,step_id, text);
                    }
                }
            }

            Alert success = new Alert(Alert.AlertType.INFORMATION);
            success.setTitle("Success");
            success.setHeaderText(null);
            success.setContentText(isEdit ? "Successfully edited." : "Successfully created.");
            success.showAndWait();

            Stage currentStage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            currentStage.close();

            if (isEdit) {
                Recipe updated = recipeDAO.getRecipeByName(name);
                Stage owner = (Stage) currentStage.getOwner();  // ✅ 关键：尝试关闭旧窗口
                if (owner != null) {
                    owner.close();
                }

                Stage newStage = new Stage();
                newStage.setTitle("Recipe Detail");
                newStage.setScene(new Scene(new CurrentRecipeView(updated), 800, 600));
                newStage.show();
            } else {
                Stage mainStage = new Stage();
                mainStage.setScene(new Scene(new MainView(), 800, 600));
                mainStage.setTitle("Main Menu");
                mainStage.show();
            }

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Invalid input or database error.");
        }
    }



    public void cancel(javafx.event.ActionEvent event) {
        Stage current = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        current.close();

        Stage mainStage = new Stage();
        mainStage.setScene(new Scene(new MainView(), 800, 600));
        mainStage.setTitle("Main Menu");
        mainStage.show();
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR, message, ButtonType.OK);
        alert.showAndWait();
    }

    private void copyFile(File source, File dest) throws IOException {
        try (FileInputStream in = new FileInputStream(source);
             FileOutputStream out = new FileOutputStream(dest)) {
            byte[] buf = new byte[1024];
            int length;
            while ((length = in.read(buf)) > 0) {
                out.write(buf, 0, length);
            }
        }
    }
}