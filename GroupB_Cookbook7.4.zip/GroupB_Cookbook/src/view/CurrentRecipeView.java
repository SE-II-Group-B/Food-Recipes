package view;

import controller.CurrentRecipeController;
import database.RecipeDAO;
import entity.Ingredient;
import entity.Recipe;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.io.File;
import java.util.List;

public class CurrentRecipeView extends BorderPane {

    private final Spinner<Integer> servingsSpinner = new Spinner<>(1, 99, 1);
    private final VBox ingredientBox = new VBox(5);
    private final VBox stepBox = new VBox(5);

    public CurrentRecipeView(Recipe recipe) {
        CurrentRecipeController controller = new CurrentRecipeController(this, recipe);
        RecipeDAO dao = new RecipeDAO();

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.setAlignment(Pos.TOP_CENTER);

        Label titleLabel = new Label(recipe.getRecipeName());
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));

        if (recipe.getImgPath() != null && !recipe.getImgPath().isEmpty()) {
            File imageFile = new File("resources/img/" + recipe.getImgPath());
            if (imageFile.exists()) {
                ImageView imageView = new ImageView(new Image(imageFile.toURI().toString()));
                imageView.setFitWidth(400);
                imageView.setPreserveRatio(true);
                content.getChildren().add(imageView);
            }
        }
        
        Label descriptionLabel = new Label(recipe.getDescription());
        descriptionLabel.setWrapText(true);
        descriptionLabel.setMaxWidth(400);
        descriptionLabel.setFont(Font.font("Arial", 14));

        HBox servingsRow = new HBox(10);
        servingsRow.setAlignment(Pos.CENTER);
        Label servingsLabel = new Label("Servings:");
        servingsRow.getChildren().addAll(servingsLabel, servingsSpinner);
        content.getChildren().addAll(titleLabel, descriptionLabel,servingsRow);

        Label ingTitle = new Label("Ingredients");
        ingTitle.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        content.getChildren().addAll(ingTitle, ingredientBox);

        List<Ingredient> ingredients = dao.getIngredientsByRecipeId(recipe.getRecipeId());
        updateIngredientList(ingredients, 1); 

        servingsSpinner.valueProperty().addListener((obs, oldVal, newVal) ->
                updateIngredientList(ingredients, newVal)
        );

        Label stepTitle = new Label("Steps");
        stepTitle.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        content.getChildren().addAll(stepTitle, stepBox);

        List<String> steps = dao.getStepsByRecipeId(recipe.getRecipeId());
        for (int i = 0; i < steps.size(); i++) {
            String step = steps.get(i);
            Label stepLabel = new Label((i + 1) + ". " + step);
            stepLabel.setWrapText(true);
            stepLabel.maxWidthProperty().bind(stepBox.widthProperty().subtract(30));
            stepBox.getChildren().add(stepLabel);
        }


        // ✅ Edit & Back 按钮
        Button edit = new Button("Edit");
        edit.setOnAction(e -> controller.editRecipe(recipe, edit));

        Button back = new Button("Back");
        back.setOnAction(e -> controller.goBack(back));

        HBox buttons = new HBox(20, back, edit);
        buttons.setAlignment(Pos.CENTER);
        content.getChildren().add(buttons);

        ScrollPane scrollPane = new ScrollPane(content);
        scrollPane.setFitToWidth(true);
        this.setCenter(scrollPane);
    }

    private void updateIngredientList(List<Ingredient> ingredients, int servings) {
        ingredientBox.getChildren().clear();
        for (Ingredient ing : ingredients) {
            int adjusted = ing.getQuantity() * servings;
            String text = String.format("%s %d %s", ing.getIngredientName(), adjusted, ing.getUnit());
            Label label = new Label(text);
            ingredientBox.getChildren().add(label);
        }
    }
}
