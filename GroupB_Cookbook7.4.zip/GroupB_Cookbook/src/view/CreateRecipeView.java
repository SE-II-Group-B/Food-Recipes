package view;

import controller.CreateRecipeController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.io.File;

public class CreateRecipeView extends BorderPane {

    private final TextField recipeNameField = new TextField();
    private final TextField imageNameField = new TextField();
    private final TextArea descriptionArea = new TextArea();
    private final VBox ingredientBox = new VBox(5);
    private final VBox stepBox = new VBox(5);
    private final VBox root = new VBox(15);
    private final CreateRecipeController controller;

    public CreateRecipeView() {
        controller = new CreateRecipeController(this);
        setPadding(new Insets(20));

        ScrollPane scrollPane = new ScrollPane(root);
        scrollPane.setFitToWidth(true);
        this.setCenter(scrollPane);

        root.setPadding(new Insets(20));
        root.setAlignment(Pos.TOP_CENTER);

        // 标题
        Label title = new Label("Create Recipe");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        root.getChildren().add(title);

        // Basic Info
        Label infoLabel = new Label("Basic Information");
        infoLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        recipeNameField.setPromptText("Enter recipe name here...");
        recipeNameField.setPrefWidth(200);
        imageNameField.setPromptText("Enter image file name here...");
        imageNameField.setPrefWidth(200);        
        descriptionArea.setPromptText("Enter recipe description here...");
        descriptionArea.setWrapText(true);
        descriptionArea.setPrefHeight(60);
        descriptionArea.setPrefWidth(400);

        HBox nameRow = new HBox(10, new Label("Recipe Name:"), recipeNameField);
        nameRow.setAlignment(Pos.CENTER_LEFT);
        
        Label descriptionLabel = new Label("Description:");
        
        HBox description = new HBox(10, descriptionLabel,descriptionArea);

        VBox infoBox = new VBox(10, infoLabel, nameRow,description);
        infoBox.setPadding(new Insets(10));
        

        // 图片选择区
        Button addPhotoButton = new Button("Add Photo");
        addPhotoButton.setPrefHeight(40);
        addPhotoButton.setPrefWidth(200);
        addPhotoButton.setOnAction(e -> controller.handleImageSelection());

        HBox imageRow = new HBox(10, addPhotoButton, imageNameField);
        imageRow.setAlignment(Pos.CENTER_LEFT);
        VBox imageBox = new VBox(10, imageRow);
        imageBox.setPadding(new Insets(10));

        // 食材部分
        Label ingLabel = new Label("Ingredients");
        ingLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));

        Button addIngredient = new Button("+");
        addIngredient.setOnAction(e -> controller.addIngredientRow());

        VBox ingredientSection = new VBox(10, ingLabel, ingredientBox, addIngredient);
        ingredientSection.setPadding(new Insets(10));

        // 步骤部分
        Label stepLabel = new Label("Steps");
        stepLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));

        Button addStep = new Button("+");
        addStep.setOnAction(e -> controller.addStepRow());

        VBox stepSection = new VBox(10, stepLabel, stepBox, addStep);
        stepSection.setPadding(new Insets(10));

        // 底部按钮
        Button saveButton = new Button("Save");
        saveButton.setOnAction(e -> controller.saveRecipe(e));

        Button cancelButton = new Button("Cancel");
        cancelButton.setOnAction(e -> controller.cancel(e));

        HBox buttons = new HBox(20, saveButton, cancelButton);
        buttons.setAlignment(Pos.CENTER);
        buttons.setPadding(new Insets(20));

        // 添加所有部分
        root.getChildren().addAll(infoBox, imageBox, ingredientSection, stepSection, buttons);

        controller.addInitialIngredients(3);
        controller.addInitialSteps(2);
    }


    public TextField getRecipeNameField() {
        return recipeNameField;
    }

    public TextField getImageNameField() {
        return imageNameField;
    }

    public VBox getIngredientBox() {
        return ingredientBox;
    }

    public VBox getStepBox() {
        return stepBox;
    }
    
    public TextArea getDescriptionArea() {
		return descriptionArea;  	
    }
}
