package view;

import controller.SearchController;
import entity.Recipe;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;

public class SearchView extends BorderPane {
    private final SearchController searchController = new SearchController();
    private final TextField searchField = new TextField();
    private final TableView<Recipe> resultTable = new TableView<>();
    private final Button backButton = new Button("Back");

    public SearchView() {
        searchField.setPromptText("请输入菜谱名进行搜索...");
        searchField.setMaxWidth(300);

        TableColumn<Recipe, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("recipeId"));
        TableColumn<Recipe, String> nameCol = new TableColumn<>("Recipe Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("recipeName"));
        resultTable.getColumns().addAll(idCol, nameCol);
        resultTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        searchField.setOnAction(e -> doSearch());
        Button searchBtn = new Button("搜索");
        searchBtn.setOnAction(e -> doSearch());

        VBox vbox = new VBox(10, searchField, searchBtn, resultTable, backButton);
        vbox.setPadding(new Insets(20));
        this.setCenter(vbox);
    }

    private void doSearch() {
        String keyword = searchField.getText().trim();
        List<Recipe> results = searchController.searchRecipes(keyword);
        ObservableList<Recipe> data = FXCollections.observableArrayList(results);
        resultTable.setItems(data);
    }

    public SearchView(String keyword) {
        TableColumn<Recipe, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("recipeId"));
        TableColumn<Recipe, String> nameCol = new TableColumn<>("Recipe Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("recipeName"));
        resultTable.getColumns().addAll(idCol, nameCol);
        resultTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        List<Recipe> results = searchController.searchRecipes(keyword);
        ObservableList<Recipe> data = FXCollections.observableArrayList(results);
        resultTable.setItems(data);

        // 跳转到 CurrentRecipeView
        resultTable.setRowFactory(tv -> {
            TableRow<Recipe> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (!row.isEmpty() && event.getClickCount() == 2) {
                    Recipe selected = row.getItem();
                    Stage thisStage = (Stage) resultTable.getScene().getWindow();
                    thisStage.hide();
                    Stage newStage = new Stage();
                    CurrentRecipeView view = new CurrentRecipeView(selected);
                    newStage.setScene(new Scene(view, 800, 600));
                    newStage.setTitle(selected.getRecipeName());
                    newStage.setOnCloseRequest(e -> thisStage.show());
                    newStage.show();
                }
            });
            return row;
        });

        // 返回主界面
        backButton.setOnAction(e -> {
            Stage thisStage = (Stage) backButton.getScene().getWindow();
            thisStage.close();

            Stage mainStage = new Stage();
            mainStage.setScene(new Scene(new MainView(), 800, 600));
            mainStage.setTitle("Main Menu");
            mainStage.show();
        });

        VBox vbox = new VBox(10, resultTable, backButton);
        vbox.setPadding(new Insets(20));
        this.setCenter(vbox);
    }
}
