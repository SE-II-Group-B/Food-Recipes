package view;

import model.Model;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.property.ReadOnlyObjectWrapper;
import controller.AllRecipeController;
import entity.Recipe;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.paint.Color;

public class AllRecipeView {
    private TableView<Recipe> table;

    public void show(Stage stage, AllRecipeController controller) {
        table = new TableView<>();
        table.setEditable(false);
        table.setPrefHeight(350);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);


        // Recipe Name Column
        TableColumn<Recipe, String> nameCol = new TableColumn<>("Recipe Name");
        nameCol.setCellValueFactory(cellData -> new ReadOnlyStringWrapper(cellData.getValue().getName()));

        // Image Path Column
        TableColumn<Recipe, String> imageCol = new TableColumn<>("Image");
        imageCol.setCellValueFactory(cellData -> new ReadOnlyStringWrapper(cellData.getValue().getImagePath()));

        // View Button Column
        TableColumn<Recipe, Button> viewCol = new TableColumn<>("View");
        viewCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(new Button("View")));

        viewCol.setCellFactory(col -> new TableCell<Recipe, Button>() {
            private final Button viewButton = new Button("View");

            {
                viewButton.setStyle(
                    "-fx-background-color: blue; " +
                    "-fx-text-fill: white; " +
                    "-fx-background-radius: 6px; " +
                    "-fx-font-weight: bold;"
                );
            }

            @Override
            protected void updateItem(Button item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || getTableRow().getItem() == null) {
                    setGraphic(null);
                } else {
                	HBox box = new HBox(viewButton);
                	box.setAlignment(Pos.CENTER);
                	setGraphic(box);

                    viewButton.setOnAction(e -> {
                        Recipe selectedRecipe = getTableRow().getItem();
                        if (selectedRecipe != null) {
                            controller.showRecipeDetail(selectedRecipe);
                        }
                    });
                }
            }
        });

        
        nameCol.setPrefWidth(1f * Integer.MAX_VALUE * 0.3);   // 30%
        imageCol.setPrefWidth(1f * Integer.MAX_VALUE * 0.6);  // 60%
        viewCol.setPrefWidth(1f * Integer.MAX_VALUE * 0.1);   // 10%

        table.getColumns().addAll(imageCol, nameCol, viewCol);

        ObservableList<Recipe> recipes = FXCollections.observableArrayList(Model.getAllRecipes());
        table.setItems(recipes);

        Label titleLabel = new Label("All Recipes");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");
        titleLabel.setPadding(new Insets(10, 0, 10, 0));
        
        VBox root = new VBox(15, titleLabel, table);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.TOP_CENTER);
        root.setBackground(new Background(new BackgroundFill(Color.web("#f9f9f9"), CornerRadii.EMPTY, Insets.EMPTY)));

        Scene scene = new Scene(root, 640, 450);
        stage.setScene(scene);
        stage.setTitle("Recipe Table");
        stage.show();
    }
}
