package controller;

public class HistoryController {
    public void onViewHistoryClicked() {
        System.out.println("Viewing recipe history");
    }
}