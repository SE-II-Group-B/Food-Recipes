package controller;

import entity.Recipe;

public class AllRecipeController {
	public void onViewRecipesClicked() {
		// Logic to handle viewing all recipes
		System.out.println("Viewing all recipes");
	}
	
	public void showRecipeDetail(Recipe recipe) {
		// Logic to show recipe details
		System.out.println("Showing details for recipe: " + recipe.getName());
	}
}
