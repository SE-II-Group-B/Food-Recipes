package view;

import controller.CurrentRecipeController;
import database.RecipeDAO;
import entity.Ingredient;
import entity.Recipe;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.io.File;
import java.util.List;

public class CurrentRecipeView extends BorderPane {

    private final Spinner<Integer> servingsSpinner = new Spinner<>(1, 99, 1);
    private final VBox ingredientBox = new VBox(5);
    private final VBox stepBox = new VBox(5);

    public CurrentRecipeView(Recipe recipe) {
        CurrentRecipeController controller = new CurrentRecipeController(this, recipe);
        RecipeDAO dao = new RecipeDAO();

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.setAlignment(Pos.TOP_CENTER);

        // ✅ 菜谱名称（加粗加大）
        Label titleLabel = new Label(recipe.getRecipeName());
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));

        // ✅ 图片展示
        if (recipe.getImgPath() != null && !recipe.getImgPath().isEmpty()) {
            File imageFile = new File("resources/img/" + recipe.getImgPath());
            if (imageFile.exists()) {
                ImageView imageView = new ImageView(new Image(imageFile.toURI().toString()));
                imageView.setFitWidth(400);
                imageView.setPreserveRatio(true);
                content.getChildren().add(imageView);
            }
        }

        // ✅ Servings 调整器
        HBox servingsRow = new HBox(10);
        servingsRow.setAlignment(Pos.CENTER);
        Label servingsLabel = new Label("Servings:");
        servingsRow.getChildren().addAll(servingsLabel, servingsSpinner);
        content.getChildren().addAll(titleLabel, servingsRow);

        // ✅ 加粗 Ingredients 标题
        Label ingTitle = new Label("Ingredients");
        ingTitle.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        content.getChildren().addAll(ingTitle, ingredientBox);

        List<Ingredient> ingredients = dao.getIngredientsByRecipeId(recipe.getRecipeId());
        updateIngredientList(ingredients, 1); // 默认份数

        servingsSpinner.valueProperty().addListener((obs, oldVal, newVal) ->
                updateIngredientList(ingredients, newVal)
        );

        // ✅ 加粗 Steps 标题
        Label stepTitle = new Label("Steps");
        stepTitle.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        content.getChildren().addAll(stepTitle, stepBox);

        List<String> steps = dao.getStepsByRecipeId(recipe.getRecipeId());
        for (int i = 0; i < steps.size(); i++) {
            String step = steps.get(i);
            Label stepLabel = new Label((i + 1) + ". " + step);
            stepBox.getChildren().add(stepLabel);
        }

        // ✅ Edit & Back 按钮
        Button edit = new Button("Edit");
        edit.setOnAction(e -> controller.editRecipe(recipe));

        Button back = new Button("Back");
        back.setOnAction(e -> controller.goBack(back));

        HBox buttons = new HBox(20, back, edit);
        buttons.setAlignment(Pos.CENTER);
        content.getChildren().add(buttons);

        ScrollPane scrollPane = new ScrollPane(content);
        scrollPane.setFitToWidth(true);
        this.setCenter(scrollPane);
    }

    private void updateIngredientList(List<Ingredient> ingredients, int servings) {
        ingredientBox.getChildren().clear();
        for (Ingredient ing : ingredients) {
            int adjusted = ing.getQuantity() * servings;
            String text = String.format("%s %d %s", ing.getIngredientName(), adjusted, ing.getUnit());
            Label label = new Label(text);
            ingredientBox.getChildren().add(label);
        }
    }
}
