该文件夹GroupB_Cookbook通过export-filesystem导出

使用方式：
1.导入方式：通过import-existing projects into workspaces导入项目

2.库：build path-library-module path中需要的库/外部JAR有3个：JavaSE-24, JavaFx-24, mysql-connector-j-8.0.33.jar (8.0版本应该都通用，放在根目录下了)，请删去原有的旧路径再添加新的

3.数据库：数据库由cookbookmethod.txt（放在根目录下了）中的代码生成，此处的代码与此前6.26上传的sql文件功能一致。暂时没有使用表recipe中的description（但表recipe中仍保留了这一项，可以考虑之后使用）。数据库连接的用户名和密码为root, 12345678，如果不一致请在RecipeDAO.java中修改

功能描述：
主界面的搜索框暂时没有功能。history界面没有功能，需要后续建立history相关表再处理

项目文件夹中的resources/img/的作用是存放菜谱展示页面内的图片。图片在img文件夹下的路径（实际上就是文件名）存放在表recipe的img_path中

其他功能基本已经实装

项目的结构：

GroupB_Cookbook/
├── src/
│   ├── controller/
│   │   ├── AllRecipeController.java
│   │   ├── CreateRecipeController.java
│   │   ├── CurrentRecipeController.java
│   │   ├── HistoryController.java
│   │   └── MainController.java
│   ├── view/
│   │   ├── AllRecipeView.java
│   │   ├── CreateRecipeView.java
│   │   ├── CurrentRecipeView.java
│   │   ├── HistoryView.java
│   │   └── MainView.java
│   ├── database/
│   │   └── RecipeDAO.java
│   ├── model/
│   │   └── Model.java
│   ├── main/
│   │   └── Main.java
│   ├── entity/
│   │   ├── Ingredient.java
│   │   └── Recipe.java
│   └── module-info.java
└── resources/
    └── img/


注意：启动选项中的vm参数暂时不需要(会出现2项警告，但不影响运行)