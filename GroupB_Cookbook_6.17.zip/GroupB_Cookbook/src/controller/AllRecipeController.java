package controller;

public class AllRecipeController {
	public void onViewRecipesClicked() {
		// Logic to handle viewing all recipes
		System.out.println("Viewing all recipes");
	}
}
