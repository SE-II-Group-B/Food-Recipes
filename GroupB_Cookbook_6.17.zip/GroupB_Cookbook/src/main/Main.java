package main;

import javafx.application.Application;
import view.MainView;

public class Main {
    public static void main(String[] args) {
        Application.launch(MainView.class, args);
    }
}
