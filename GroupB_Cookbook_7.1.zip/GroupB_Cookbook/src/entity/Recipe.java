package entity;

public class Recipe {
    private int recipeId;
    private String recipeName;
    private String imgPath;

    // ✅ 构造函数（支持快速创建）
    public Recipe(int recipeId, String recipeName, String imgPath) {
        this.recipeId = recipeId;
        this.recipeName = recipeName;
        this.imgPath = imgPath;
    }

    // ✅ 无参构造函数（用于反射或空对象）
    public Recipe() {}

    public int getRecipeId() {
        return recipeId;
    }

    public void setRecipeId(int recipeId) {
        this.recipeId = recipeId;
    }

    public String getRecipeName() {
        return recipeName;
    }

    public void setRecipeName(String recipeName) {
        this.recipeName = recipeName;
    }

    public String getImgPath() {
        return imgPath;
    }

    public void setImgPath(String imgPath) {
        this.imgPath = imgPath;
    }
}
