package view;

import controller.MainController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

public class MainView extends BorderPane {

    private final MainController controller = new MainController();

    public MainView() {
        this.setPadding(new Insets(20));

        // 顶部按钮区域
        Button allRecipeButton = new Button("All Recipes");
        Button createRecipeButton = new Button("Create Recipe");
        Button historyButton = new Button("History");

        HBox topButtons = new HBox(20, allRecipeButton, createRecipeButton, historyButton);
        topButtons.setAlignment(Pos.CENTER);
        topButtons.setPadding(new Insets(20));

        // 搜索框（暂不处理搜索功能）
        TextField searchField = new TextField();
        searchField.setPromptText("Search recipes...");
        searchField.setMaxWidth(300);
        VBox centerBox = new VBox(searchField);
        centerBox.setAlignment(Pos.CENTER);

        // 绑定按钮逻辑（使用主窗口为 source）
        allRecipeButton.setOnAction(e -> controller.openAllRecipe(allRecipeButton));
        createRecipeButton.setOnAction(e -> controller.openCreateRecipe(createRecipeButton));
        historyButton.setOnAction(e -> controller.openHistory(historyButton));

        this.setTop(topButtons);
        this.setCenter(centerBox);
    }
}
