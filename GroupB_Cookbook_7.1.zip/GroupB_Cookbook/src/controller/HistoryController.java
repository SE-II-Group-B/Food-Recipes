package controller;

import entity.Recipe;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.stage.Stage;
import view.CurrentRecipeView;
import view.MainView;

public class HistoryController {

    public void openRecipeDetail(Recipe recipe, Node source) {
        // 关闭当前窗口
        Stage current = (Stage) source.getScene().getWindow();
        current.close();

        // 打开详情视图
        CurrentRecipeView detailView = new CurrentRecipeView(recipe);
        Stage stage = new Stage();
        stage.setTitle("Recipe Detail");
        stage.setScene(new Scene(detailView, 800, 600));
        stage.show();
    }

    public void goBackToMain(Node source) {
        // 关闭当前窗口
        Stage current = (Stage) source.getScene().getWindow();
        current.close();

        // 返回主界面
        MainView mainView = new MainView();
        Stage stage = new Stage();
        stage.setTitle("Main Menu");
        stage.setScene(new Scene(mainView, 800, 600));
        stage.show();
    }
}
