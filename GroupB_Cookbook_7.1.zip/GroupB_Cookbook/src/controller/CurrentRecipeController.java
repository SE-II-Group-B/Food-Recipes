package controller;

import database.RecipeDAO;
import entity.Ingredient;
import entity.Recipe;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import view.CreateRecipeView;
import view.CurrentRecipeView;

import java.util.List;

public class CurrentRecipeController {

    private final Recipe recipe;

    public CurrentRecipeController(CurrentRecipeView view, Recipe recipe) {
        this.recipe = recipe;
    }

    public void editRecipe(Recipe recipe, javafx.scene.Node source) {
        // ✅ 关闭当前窗口（CurrentRecipe）
        Stage currentStage = (Stage) source.getScene().getWindow();
        currentStage.close();

        CreateRecipeView view = new CreateRecipeView();
        CreateRecipeController controller = new CreateRecipeController(view);

        // ✅ 设置基本字段
        view.getRecipeNameField().setText(recipe.getRecipeName());
        view.getImageNameField().setText(recipe.getImgPath());

        // ✅ 设置食材
        RecipeDAO dao = new RecipeDAO();
        List<Ingredient> ingredients = dao.getIngredientsByRecipeId(recipe.getRecipeId());
        for (int i = 0; i < ingredients.size(); i++) {
            if (i >= 3) controller.addIngredientRow();
            Ingredient ing = ingredients.get(i);
            HBox row = (HBox) view.getIngredientBox().getChildren().get(i);
            ((TextField) row.getChildren().get(0)).setText(ing.getIngredientName());
            ((TextField) row.getChildren().get(1)).setText(String.valueOf(ing.getQuantity()));
            ((TextField) row.getChildren().get(2)).setText(ing.getUnit());
        }

        // ✅ 设置步骤
        List<String> steps = dao.getStepsByRecipeId(recipe.getRecipeId());
        for (int i = 0; i < steps.size(); i++) {
            if (i >= 2) controller.addStepRow();
            HBox row = (HBox) view.getStepBox().getChildren().get(i);
            ((TextArea) row.getChildren().get(0)).setText(steps.get(i));
        }

        // ✅ 显示编辑窗口
        Stage stage = new Stage();
        stage.setTitle("Edit Recipe");
        stage.setScene(new Scene(view, 800, 600));
        stage.show();
    }

    public void goBack(javafx.scene.Node source) {
        Stage current = (Stage) source.getScene().getWindow();
        current.close();

        Stage mainStage = new Stage();
        mainStage.setTitle("Main Menu");
        mainStage.setScene(new Scene(new view.MainView(), 800, 600));
        mainStage.show();
    }
}
