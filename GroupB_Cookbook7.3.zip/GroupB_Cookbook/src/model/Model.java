package model;

import database.RecipeDAO;
import entity.Recipe;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Model {
    private ObservableList<Recipe> recipes = FXCollections.observableArrayList();
    private RecipeDAO recipeDAO = new RecipeDAO();

    public Model() {
        loadRecipes();
    }

    private void loadRecipes() {
        recipes.setAll(recipeDAO.getAllRecipes());
    }

    public ObservableList<Recipe> getRecipes() {
        return recipes;
    }
}
