package controller;

import entity.Recipe;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.stage.Stage;
import view.CurrentRecipeView;
import view.MainView;
import database.RecipeDAO;
import java.util.List;
import java.util.Map;

public class HistoryController {

    public void openRecipeDetail(Recipe recipe, Node source) {
        // 关闭当前窗口
        Stage current = (Stage) source.getScene().getWindow();
        current.close();

        // 打开详情视图
        CurrentRecipeView detailView = new CurrentRecipeView(recipe);
        Stage stage = new Stage();
        stage.setTitle("Recipe Detail");
        stage.setScene(new Scene(detailView, 800, 600));
        stage.show();
    }

    public void goBackToMain(Node source) {
        // 关闭当前窗口
        Stage current = (Stage) source.getScene().getWindow();
        current.close();

        // 返回主界面
        MainView mainView = new MainView();
        Stage stage = new Stage();
        stage.setTitle("Main Menu");
        stage.setScene(new Scene(mainView, 800, 600));
        stage.show();
    }

    /**
     * 获取最近十次不重复的被搜索菜谱名
     */
    public List<String> getRecentSearchedRecipes() {
        RecipeDAO dao = new RecipeDAO();
        return dao.getRecentSearchedRecipes();
    }

    /**
     * 根据菜谱名查找 Recipe 对象
     */
    public Recipe getRecipeByName(String name) {
        RecipeDAO dao = new RecipeDAO();
        return dao.getRecipeByName(name);
    }

    /**
     * 获取最近十次不重复的被搜索菜谱名和搜索时间
     */
    public List<Map.Entry<String, String>> getRecentSearchedRecipeEntries() {
        RecipeDAO dao = new RecipeDAO();
        return dao.getRecentSearchedRecipeEntries();
    }
}
