package controller;

import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.stage.Stage;
import view.AllRecipeView;
import view.CreateRecipeView;
import view.HistoryView;
import view.SearchView;
import view.EditRecipeView; // 统一导入

public class MainController {

    public void openAllRecipe(Node triggerNode) {
        Stage mainStage = (Stage) triggerNode.getScene().getWindow();
        mainStage.hide();

        Stage newStage = new Stage();
        AllRecipeView view = new AllRecipeView();
        newStage.setScene(new Scene(view, 800, 600));
        newStage.setTitle("All Recipes");
        newStage.setOnCloseRequest(e -> mainStage.show()); // “X” 时恢复主界面
        newStage.show();
    }

    public void openCreateRecipe(Node triggerNode) {
        Stage mainStage = (Stage) triggerNode.getScene().getWindow();
        mainStage.hide();

        Stage createStage = new Stage();
        CreateRecipeView view = new CreateRecipeView();
        CreateRecipeController controller = new CreateRecipeController(view);
        controller.setReturnStage(mainStage);
        controller.setWindowCloseHandler(createStage);
        createStage.setScene(new Scene(view, 800, 600));
        createStage.setTitle("Create Recipe");
        createStage.show();
    }

    public void openHistory(Node triggerNode) {
        Stage mainStage = (Stage) triggerNode.getScene().getWindow();
        mainStage.hide();

        Stage newStage = new Stage();
        HistoryView view = new HistoryView();
        newStage.setScene(new Scene(view, 800, 600));
        newStage.setTitle("History");
        newStage.setOnCloseRequest(e -> mainStage.show());
        newStage.show();
    }

    public void openSearchView(Node triggerNode, String keyword) {
        Stage mainStage = (Stage) triggerNode.getScene().getWindow();
        mainStage.hide();

        Stage newStage = new Stage();
        SearchView view = new SearchView(keyword);
        newStage.setScene(new Scene(view, 800, 600));
        newStage.setTitle("Search Results");
        newStage.setOnCloseRequest(e -> mainStage.show());
        newStage.show();
    }

    public void openEditRecipe(Node triggerNode, entity.Recipe recipe) {
        Stage mainStage = (Stage) triggerNode.getScene().getWindow();
        mainStage.hide();

        Stage newStage = new Stage();
        EditRecipeView view = new EditRecipeView(recipe); // 统一写法
        newStage.setScene(new Scene(view, 800, 600));
        newStage.setTitle("Edit Recipe");
        newStage.setOnCloseRequest(e -> mainStage.show()); // 关闭编辑窗口时恢复主界面
        newStage.show();
    }
}
