package controller;

import entity.Recipe;
import model.RecipeDAO;

import java.util.List;

public class SearchController {
    /**
     * 根据关键字模糊搜索菜谱，并写入history表
     */
    public List<Recipe> searchRecipes(String keyword) {
        RecipeDAO dao = new RecipeDAO();
        return dao.searchRecipesByName(keyword);
    }
}
