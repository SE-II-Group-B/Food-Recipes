package model;

import entity.Ingredient;
import entity.Recipe;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RecipeDAO {
	
	private static final String DB_URL = "jdbc:mysql://localhost:3306/cookbook";
	private static final String USER="root";
	private static final String PASS="1021";

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, USER, PASS);
    }
     
    public String getURL() {
		return DB_URL;
	}
    
    public String getUser() {
    	return USER;
    }
    
    public String getPass() {
		return PASS;
	}
    
    public void insertRecipe(int recipeId, String name, String description, String imgPath, String preptime) {
        String sql = "INSERT INTO recipe (recipe_id, recipe_name, description, img_path, preptime) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, recipeId);
            stmt.setString(2, name);
            stmt.setString(3, description);
            stmt.setString(4, imgPath);
            stmt.setString(5, preptime);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void insertIngredient(int recipeId, String name, String unit, int quantity) {
        String sql = "INSERT INTO ingredient (recipe_id, ingredient_name, unit, quantity) VALUES (?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, recipeId);
            stmt.setString(2, name);
            stmt.setString(3, unit);
            stmt.setInt(4, quantity);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void insertStep(int recipeId, int step_id,String instruction) {
        String sql = "INSERT INTO step (recipe_id, step_id, instruction) VALUES (?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, recipeId);
            stmt.setInt(2, step_id);
            stmt.setString(3, instruction);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteRecipeById(int recipeId) {
        String deleteStep = "DELETE FROM step WHERE recipe_id = ?";
        String deleteIngredient = "DELETE FROM ingredient WHERE recipe_id = ?";
        String deleteRecipe = "DELETE FROM recipe WHERE recipe_id = ?";
        try (Connection conn = getConnection()) {
            try (PreparedStatement psStep = conn.prepareStatement(deleteStep);
                 PreparedStatement psIngredient = conn.prepareStatement(deleteIngredient);
                 PreparedStatement psRecipe = conn.prepareStatement(deleteRecipe)) {
                psStep.setInt(1, recipeId);
                psStep.executeUpdate();

                psIngredient.setInt(1, recipeId);
                psIngredient.executeUpdate();

                psRecipe.setInt(1, recipeId);
                psRecipe.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Recipe> getAllRecipes() {
        List<Recipe> list = new ArrayList<>();
        String sql = "SELECT * FROM recipe ORDER BY recipe_id ASC";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Recipe r = new Recipe();
                r.setRecipeId(rs.getInt("recipe_id"));
                r.setRecipeName(rs.getString("recipe_name"));
                r.setDescription(rs.getString("description"));
                r.setImgPath(rs.getString("img_path"));
                r.setPreptime(rs.getString("preptime"));
                list.add(r);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Ingredient> getIngredientsByRecipeId(int recipeId) {
        List<Ingredient> list = new ArrayList<>();
        String sql = "SELECT * FROM ingredient WHERE recipe_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, recipeId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Ingredient ing = new Ingredient();
                    ing.setIngredientId(rs.getInt("ingredient_id"));
                    ing.setRecipeId(recipeId);
                    ing.setIngredientName(rs.getString("ingredient_name"));
                    ing.setUnit(rs.getString("unit"));
                    ing.setQuantity(rs.getInt("quantity"));
                    list.add(ing);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<String> getStepsByRecipeId(int recipeId) {
        List<String> list = new ArrayList<>();
        String sql = "SELECT instruction FROM step WHERE recipe_id = ? ORDER BY step_id ASC";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, recipeId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(rs.getString("instruction"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // 判断是否存在指定 recipe_name，用于isEdit状态判断
    public Recipe getRecipeByName(String name) {
        String sql = "SELECT * FROM recipe WHERE recipe_name = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, name);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Recipe recipe = new Recipe();
                    recipe.setRecipeId(rs.getInt("recipe_id"));
                    recipe.setRecipeName(rs.getString("recipe_name"));
                    recipe.setDescription(rs.getString("description"));
                    recipe.setImgPath(rs.getString("img_path"));
                    recipe.setPreptime(rs.getString("preptime"));
                    return recipe;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }


    
    public int getNextAvailableRecipeId() {
        int id = 1;
        String query = "SELECT recipe_id FROM recipe ORDER BY recipe_id";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                if (rs.getInt("recipe_id") == id) {
                    id++;
                } else {
                    break;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return id;
    }

    public void saveRecipe(Recipe recipe) {
        String sql = "INSERT INTO recipe (recipe_id, recipe_name, description, img_path, preptime) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, recipe.getRecipeId());
            stmt.setString(2, recipe.getRecipeName());
            stmt.setString(3, recipe.getDescription());
            stmt.setString(4, recipe.getImgPath());
            stmt.setString(5, recipe.getPreptime());
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateRecipe(Recipe recipe) {
        String sql = "UPDATE recipe SET recipe_name = ?, description = ?, img_path = ?, preptime = ? WHERE recipe_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, recipe.getRecipeName());
            stmt.setString(2, recipe.getDescription());
            stmt.setString(3, recipe.getImgPath());
            stmt.setString(4, recipe.getPreptime());
            stmt.setInt(5, recipe.getRecipeId());
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public Recipe getRecipeById(int id) {
        String sql = "SELECT * FROM recipe WHERE recipe_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Recipe recipe = new Recipe();
                    recipe.setRecipeId(rs.getInt("recipe_id"));
                    recipe.setRecipeName(rs.getString("recipe_name"));
                    recipe.setDescription(rs.getString("description"));
                    recipe.setImgPath(rs.getString("img_path"));
                    recipe.setPreptime(rs.getString("preptime"));
                    return recipe;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 获取最近十次不重复的被搜索菜谱（按SearchTime倒序，recipe_name唯一）
     */
    public List<String> getRecentSearchedRecipes() {
        List<String> list = new ArrayList<>();
        String sql = "SELECT recipe_name FROM history GROUP BY recipe_name ORDER BY MAX(SearchTime) DESC LIMIT 10";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                list.add(rs.getString("recipe_name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 模糊搜索菜谱名，并写入history表
     */
    public List<Recipe> searchRecipesByName(String keyword) {
        List<Recipe> result = new ArrayList<>();
        String sql = "SELECT * FROM recipe WHERE recipe_name LIKE ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, "%" + keyword + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Recipe r = new Recipe();
                    r.setRecipeId(rs.getInt("recipe_id"));
                    r.setRecipeName(rs.getString("recipe_name"));
                    r.setImgPath(rs.getString("img_path"));
                    result.add(r);
                    // 不再写入history
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 向history表插入或更新一条记录（如已存在则更新时间，否则插入新行）
     */
    public void insertHistory(String recipeName) {
        String sql = "INSERT INTO history (recipe_name, SearchTime) VALUES (?, NOW()) " +
                "ON DUPLICATE KEY UPDATE SearchTime = NOW()";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, recipeName);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取最近十次不重复的被搜索菜谱名和搜索时间（按SearchTime倒序，recipe_name唯一）
     * @return List<Map.Entry<String, String>>，key为菜名，value为搜索时间
     */
    public List<java.util.Map.Entry<String, String>> getRecentSearchedRecipeEntries() {
        List<java.util.Map.Entry<String, String>> list = new java.util.ArrayList<>();
        String sql = "SELECT recipe_name, MAX(SearchTime) as SearchTime FROM history GROUP BY recipe_name ORDER BY SearchTime DESC LIMIT 10";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String name = rs.getString("recipe_name");
                String time = rs.getString("SearchTime");
                list.add(new java.util.AbstractMap.SimpleEntry<>(name, time));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
