package view;

import controller.HistoryController;
import entity.Recipe;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class HistoryView extends BorderPane {

    private final TableView<Recipe> historyTable = new TableView<>();
    private final Button backButton = new Button("Back");
    private final Button exportButton = new Button("Export");
    private final Button clearButton = new Button("Clear");
    private final HistoryController controller = new HistoryController();

    public HistoryView() {
        // 只展示菜谱名和搜索时间
        TableColumn<Recipe, String> nameCol = new TableColumn<>("Recipe Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("recipeName"));
        TableColumn<Recipe, String> timeCol = new TableColumn<>("Search Time");
        timeCol.setCellValueFactory(new PropertyValueFactory<>("searchTime"));

        historyTable.getColumns().addAll(nameCol, timeCol);
        historyTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        historyTable.setItems(loadHistoryData()); // 修改为真实历史数据

        historyTable.setRowFactory(tv -> {
            TableRow<Recipe> row = new TableRow<>();
            row.setOnMouseClicked(e -> {
                if (!row.isEmpty()) {
                    Recipe selected = row.getItem();
                    controller.openRecipeDetail(selected, row);
                }
            });
            return row;
        });

        backButton.setOnAction(e -> controller.goBackToMain(backButton));
        exportButton.setOnAction(e -> controller.exportHistoryToTxt(historyTable));
        clearButton.setOnAction(e -> controller.clearHistory(historyTable));

        VBox content = new VBox(20, historyTable, new HBox(20, exportButton, clearButton, backButton));
        content.setPadding(new Insets(20));

        ScrollPane scrollPane = new ScrollPane(content);
        scrollPane.setFitToWidth(true);

        this.setCenter(scrollPane);

        // 设置关闭按钮行为
        this.sceneProperty().addListener((obs, oldScene, newScene) -> {
        	newScene.windowProperty().addListener((obsWin, oldWin, newWin) -> {
                if (newWin instanceof Stage) {
                    Stage stage = (Stage) newWin;
                    stage.setOnCloseRequest(e -> controller.goBackToMain(historyTable));
                }
            });
        });
    }

    /**
     * 加载最近十次不重复的被搜索菜谱（查名字和搜索时间）
     */
    private ObservableList<Recipe> loadHistoryData() {
        ObservableList<Recipe> list = FXCollections.observableArrayList();
        for (var entry : controller.getRecentSearchedRecipeEntries()) { // List<Map.Entry<String, String>>
            String name = entry.getKey();
            String time = entry.getValue();
            Recipe recipe = controller.getRecipeByName(name);
            if (recipe != null) {
                recipe.setSearchTime(time); // 需要在Recipe类中添加searchTime字段及setter
                list.add(recipe);
            }
        }
        return list;
    }
}
