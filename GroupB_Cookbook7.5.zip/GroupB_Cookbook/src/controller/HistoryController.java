package controller;

import entity.Recipe;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.stage.Stage;
import view.CurrentRecipeView;
import view.MainView;
import database.RecipeDAO;
import java.util.List;
import java.util.Map;

public class HistoryController {

    public void openRecipeDetail(Recipe recipe, Node source) {
        // 关闭当前窗口
        Stage current = (Stage) source.getScene().getWindow();
        current.close();

        // 写入history
        RecipeDAO dao = new RecipeDAO();
        dao.insertHistory(recipe.getRecipeName());

        // 打开详情视图
        CurrentRecipeView detailView = new CurrentRecipeView(recipe);
        Stage stage = new Stage();
        stage.setTitle("Recipe Detail");
        stage.setScene(new Scene(detailView, 800, 600));
        stage.show();
    }

    public void goBackToMain(Node source) {
        // 关闭当前窗口
        Stage current = (Stage) source.getScene().getWindow();
        current.close();

        // 返回主界面
        MainView mainView = new MainView();
        Stage stage = new Stage();
        stage.setTitle("Main Menu");
        stage.setScene(new Scene(mainView, 800, 600));
        stage.show();
    }

    /**
     * 获取最近十次不重复的被搜索菜谱名
     */
    public List<String> getRecentSearchedRecipes() {
        RecipeDAO dao = new RecipeDAO();
        return dao.getRecentSearchedRecipes();
    }

    /**
     * 根据菜谱名查找 Recipe 对象
     */
    public Recipe getRecipeByName(String name) {
        RecipeDAO dao = new RecipeDAO();
        return dao.getRecipeByName(name);
    }

    /**
     * 获取最近十次不重复的被搜索菜谱名和搜索时间
     */
    public List<Map.Entry<String, String>> getRecentSearchedRecipeEntries() {
        RecipeDAO dao = new RecipeDAO();
        return dao.getRecentSearchedRecipeEntries();
    }

    public void exportHistoryToTxt(javafx.scene.control.TableView<entity.Recipe> table) {
        javafx.stage.FileChooser fileChooser = new javafx.stage.FileChooser();
        fileChooser.setTitle("Export History");
        fileChooser.setInitialFileName("history.txt");
        java.io.File file = fileChooser.showSaveDialog(null);
        if (file != null) {
            try (java.io.PrintWriter writer = new java.io.PrintWriter(file, "UTF-8")) {
                int timeStart = 60; // search time 距离最左端的固定位置
                String header = String.format("%-" + timeStart + "s%s", "Recipe Name", "Search Time");
                writer.println(header);
                for (entity.Recipe recipe : table.getItems()) {
                    String name = recipe.getRecipeName() != null ? recipe.getRecipeName() : "";
                    String time = recipe.getSearchTime() != null ? recipe.getSearchTime() : "";
                    // 用空格补齐到 timeStart
                    int pad = Math.max(1, timeStart - name.length());
                    String gapStr = " ".repeat(pad);
                    writer.println(name + gapStr + time);
                }
                javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION, "Export successful!", javafx.scene.control.ButtonType.OK);
                alert.showAndWait();
            } catch (Exception e) {
                e.printStackTrace();
                javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR, "Export failed!", javafx.scene.control.ButtonType.OK);
                alert.showAndWait();
            }
        }
    }

    public void clearHistory(javafx.scene.control.TableView<entity.Recipe> table) {
        // 清空history表
        try {
            RecipeDAO dao = new RecipeDAO();
            java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/cookbook", "root", "1021");
            try (java.sql.Statement stmt = conn.createStatement()) {
                stmt.executeUpdate("DELETE FROM history");
            }
            conn.close();
            // 刷新表格
            table.getItems().clear();
            javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION, "History cleared!", javafx.scene.control.ButtonType.OK);
            alert.showAndWait();
        } catch (Exception e) {
            e.printStackTrace();
            javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR, "Clear failed!", javafx.scene.control.ButtonType.OK);
            alert.showAndWait();
        }
    }
}
