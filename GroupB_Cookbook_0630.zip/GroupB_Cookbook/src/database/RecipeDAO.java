package database;

import entity.Ingredient;
import entity.Recipe;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RecipeDAO {

    private static final String URL = "jdbc:mysql://localhost:3306/cookbook";
    private static final String USER = "root";
    private static final String PASSWORD = "12345678";

    public void insertRecipe(int recipeId, String name, String imgPath) {
        String sql = "INSERT INTO recipe (recipe_id, recipe_name, img_path) VALUES (?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, recipeId);
            stmt.setString(2, name);
            stmt.setString(3, imgPath);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void insertIngredient(int recipeId, String name, String unit, int quantity) {
        String sql = "INSERT INTO ingredient (recipe_id, ingredient_name, unit, quantity) VALUES (?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, recipeId);
            stmt.setString(2, name);
            stmt.setString(3, unit);
            stmt.setInt(4, quantity);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void insertStep(int recipeId, String instruction) {
        String sql = "INSERT INTO step (recipe_id, instruction) VALUES (?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, recipeId);
            stmt.setString(2, instruction);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteRecipeById(int recipeId) {
        String deleteStep = "DELETE FROM step WHERE recipe_id = ?";
        String deleteIngredient = "DELETE FROM ingredient WHERE recipe_id = ?";
        String deleteRecipe = "DELETE FROM recipe WHERE recipe_id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            try (PreparedStatement psStep = conn.prepareStatement(deleteStep);
                 PreparedStatement psIngredient = conn.prepareStatement(deleteIngredient);
                 PreparedStatement psRecipe = conn.prepareStatement(deleteRecipe)) {
                psStep.setInt(1, recipeId);
                psStep.executeUpdate();

                psIngredient.setInt(1, recipeId);
                psIngredient.executeUpdate();

                psRecipe.setInt(1, recipeId);
                psRecipe.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Recipe> getAllRecipes() {
        List<Recipe> list = new ArrayList<>();
        String sql = "SELECT * FROM recipe ORDER BY recipe_id ASC";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Recipe r = new Recipe();
                r.setRecipeId(rs.getInt("recipe_id"));
                r.setRecipeName(rs.getString("recipe_name"));
                r.setImgPath(rs.getString("img_path"));
                list.add(r);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Ingredient> getIngredientsByRecipeId(int recipeId) {
        List<Ingredient> list = new ArrayList<>();
        String sql = "SELECT * FROM ingredient WHERE recipe_id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, recipeId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Ingredient ing = new Ingredient();
                    ing.setIngredientId(rs.getInt("ingredient_id"));
                    ing.setRecipeId(recipeId);
                    ing.setIngredientName(rs.getString("ingredient_name"));
                    ing.setUnit(rs.getString("unit"));
                    ing.setQuantity(rs.getInt("quantity"));
                    list.add(ing);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<String> getStepsByRecipeId(int recipeId) {
        List<String> list = new ArrayList<>();
        String sql = "SELECT instruction FROM step WHERE recipe_id = ? ORDER BY step_id ASC";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, recipeId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(rs.getString("instruction"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // 判断是否存在指定 recipe_id
    public Recipe getRecipeById(int recipeId) {
        String sql = "SELECT * FROM recipe WHERE recipe_id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, recipeId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Recipe recipe = new Recipe();
                    recipe.setRecipeId(rs.getInt("recipe_id"));
                    recipe.setRecipeName(rs.getString("recipe_name"));
                    recipe.setImgPath(rs.getString("img_path"));
                    return recipe;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    // get the smallest available recipe_id (when creating new recipe)
    public int getNextAvailableRecipeId() throws SQLException {
        String sql = "SELECT recipe_id FROM recipe ORDER BY recipe_id";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            int expectedId = 1;
            while (rs.next()) {
                int currentId = rs.getInt("recipe_id");
                if (currentId != expectedId) {
                    break;
                }
                expectedId++;
            }
            return expectedId;
        }
    }

}
