package controller;

import database.RecipeDAO;
import entity.Ingredient;
import entity.Recipe;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import view.CreateRecipeView;
import view.CurrentRecipeView;


import java.util.List;

public class CurrentRecipeController {

    private final Recipe recipe;

    public CurrentRecipeController(CurrentRecipeView view, Recipe recipe) {
        this.recipe = recipe;
    }

    public void goBack(javafx.scene.Node source) {
        Stage current = (Stage) source.getScene().getWindow();
        current.close(); // 仅关闭当前窗口
    }

    public void editRecipe(Recipe recipe) {
        Stage current = (Stage) javafx.stage.Window.getWindows().stream()
                .filter(w -> w.getScene() != null && w.getScene().getRoot().getUserData() == this)
                .findFirst()
                .orElse(null);

        if (current != null) current.close(); // 关闭当前窗口

        CreateRecipeView editView = new CreateRecipeView();
        CreateRecipeController editController = new CreateRecipeController(editView);

        // 填入基本信息
        editView.getRecipeNameField().setText(recipe.getRecipeName());
        editView.getImageNameField().setText(recipe.getImgPath());

        // 填入食材
        RecipeDAO dao = new RecipeDAO();
        List<Ingredient> ingredients = dao.getIngredientsByRecipeId(recipe.getRecipeId());
        for (int i = 0; i < ingredients.size(); i++) {
            if (i >= 3) editController.addIngredientRow(); // 初始3行之外手动添加
            Ingredient ing = ingredients.get(i);
            HBox row = (HBox) editView.getIngredientBox().getChildren().get(i);
            ((TextField) row.getChildren().get(0)).setText(ing.getIngredientName());
            ((TextField) row.getChildren().get(1)).setText(String.valueOf(ing.getQuantity()));
            ((TextField) row.getChildren().get(2)).setText(ing.getUnit());
        }

        // 填入步骤
        List<String> steps = dao.getStepsByRecipeId(recipe.getRecipeId());
        for (int i = 0; i < steps.size(); i++) {
            if (i >= 2) editController.addStepRow(); // 初始2行之外手动添加
            HBox row = (HBox) editView.getStepBox().getChildren().get(i);
            ((TextArea) row.getChildren().get(0)).setText(steps.get(i));
        }

        Stage stage = new Stage();
        stage.setTitle("Edit Recipe");
        stage.setScene(new Scene(editView, 800, 600));
        stage.show();
    }
}
